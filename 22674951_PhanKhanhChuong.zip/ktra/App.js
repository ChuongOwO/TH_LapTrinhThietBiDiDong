import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  Pressable,
} from 'react-native';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text>Nhập phép tính</Text>
      </View>
      <View style={styles.components}>
        <View style={styles.button}>
          <TouchableOpacity>1</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>2</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>3</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>4</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>5</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>6</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>7</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>8</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>9</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>0</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>+</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>-</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>*</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>/</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>=</TouchableOpacity>
        </View>
        <View style={styles.button}>
          <TouchableOpacity>C</TouchableOpacity>
        </View>
        const button = [
          ["7", "8", "9", "/"],
          ["4", "5", "6", "*"],
          ["1", "2", "3", "-"],
          ["0", ".", "=", "+"],
          ["C"]];
        ]
      </View>

      <View>
        <TextInput></TextInput>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    maxWidth: 70
  },
  components: {},
  button: {
    backgroundColor: '#ddd',
    margin: 8,
    padding: 2,
    width: 15,
  },
});
